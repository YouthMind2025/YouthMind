package ai.youthmind.interests;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Testcontainers
public class InterestControllerIT {

    @Container
    static PostgreSQLContainer<?> pg = new PostgreSQLContainer<>("postgres:16-alpine");

    @DynamicPropertySource
    static void props(DynamicPropertyRegistry r) {
        r.add("spring.datasource.url", pg::getJdbcUrl);
        r.add("spring.datasource.username", pg::getUsername);
        r.add("spring.datasource.password", pg::getPassword);
    }

    @LocalServerPort int port;
    @Autowired TestRestTemplate rest;

    @Test
    void shouldRecomputeAndListInterests() {
        UUID userId = UUID.randomUUID();
        ResponseEntity<String> recompute = rest.postForEntity(url("/api/interests/recompute/" + userId + "?top=10"), null, String.class);
        assertThat(recompute.getStatusCode().is2xxSuccessful()).isTrue();

        ResponseEntity<String> list = rest.getForEntity(url("/api/interests/" + userId), String.class);
        assertThat(list.getStatusCode().is2xxSuccessful()).isTrue();
    }

    private String url(String p) { return "http://localhost:" + port + p; }
}
