package ai.youthmind.memory;

import ai.youthmind.memory.dto.MemoryAppendRequest;
import ai.youthmind.memory.dto.PreferenceSetRequest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Testcontainers
public class MemoryControllerIT {

    @Container
    static PostgreSQLContainer<?> pg = new PostgreSQLContainer<>("postgres:16-alpine");

    @DynamicPropertySource
    static void props(DynamicPropertyRegistry r) {
        r.add("spring.datasource.url", pg::getJdbcUrl);
        r.add("spring.datasource.username", pg::getUsername);
        r.add("spring.datasource.password", pg::getPassword);
    }

    @LocalServerPort int port;
    @Autowired TestRestTemplate rest;

    @Test
    void shouldAppendMemoryAndSetPref() {
        UUID userId = UUID.randomUUID();
        MemoryAppendRequest mem = new MemoryAppendRequest();
        mem.userId = userId; mem.role = "user"; mem.content = "hello"; mem.ttlSeconds = 3600L;

        ResponseEntity<Void> ack = rest.postForEntity(url("/api/memory/append"), mem, Void.class);
        assertThat(ack.getStatusCode().is2xxSuccessful()).isTrue();

        ResponseEntity<String> ctx = rest.getForEntity(url("/api/memory/context?userId=" + userId), String.class);
        assertThat(ctx.getStatusCode().is2xxSuccessful()).isTrue();

        PreferenceSetRequest pref = new PreferenceSetRequest();
        pref.userId = userId; pref.key = "lang"; pref.value = Map.of("value","en");
        ResponseEntity<String> set = rest.postForEntity(url("/api/memory/pref/set"), pref, String.class);
        assertThat(set.getStatusCode().is2xxSuccessful()).isTrue();

        ResponseEntity<String> get = rest.getForEntity(url("/api/memory/pref/get?userId=" + userId + "&key=lang"), String.class);
        assertThat(get.getStatusCode().is2xxSuccessful()).isTrue();
    }

    private String url(String p) { return "http://localhost:" + port + p; }
}
