package ai.youthmind.analytics;

import ai.youthmind.analytics.dto.ViewEventRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.AfterAll;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.*;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Testcontainers
public class BehaviorAnalyticsControllerIT {

    @Container
    static PostgreSQLContainer<?> pg = new PostgreSQLContainer<>("postgres:16-alpine");

    @DynamicPropertySource
    static void props(DynamicPropertyRegistry r) {
        r.add("spring.datasource.url", pg::getJdbcUrl);
        r.add("spring.datasource.username", pg::getUsername);
        r.add("spring.datasource.password", pg::getPassword);
    }

    @LocalServerPort int port;
    @Autowired TestRestTemplate rest;

    @Test
    void shouldTrackViewAndReturnSummary() {
        ViewEventRequest req = new ViewEventRequest();
        req.userId = UUID.randomUUID();
        req.postId = UUID.randomUUID();
        req.durationMs = 1234;
        req.metadata = Map.of("client", "it");

        ResponseEntity<Void> ack = rest.postForEntity(url("/api/behavior/view"), req, Void.class);
        assertThat(ack.getStatusCode()).isEqualTo(HttpStatus.ACCEPTED);

        ResponseEntity<String> res = rest.getForEntity(url("/api/behavior/summary/" + req.userId + "?days=7"), String.class);
        assertThat(res.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(res.getBody()).contains("totalViewMs"); // smoke check
    }

    private String url(String p) { return "http://localhost:" + port + p; }
}
