package ai.youthmind.memory.dto;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

public class ContextResponse {
    public UUID userId;
    public UUID conversationId;
    public List<MemoryItem> items;
    public Instant generatedAt;

    public ContextResponse(UUID userId, UUID conversationId, List<MemoryItem> items, Instant generatedAt) {
        this.userId = userId; this.conversationId = conversationId; this.items = items; this.generatedAt = generatedAt;
    }

    public static class MemoryItem {
        public String role; public String content; public String metadata; public Instant createdAt;
        public MemoryItem(String role, String content, String metadata, Instant createdAt) {
            this.role = role; this.content = content; this.metadata = metadata; this.createdAt = createdAt; }
    }
}
