package ai.youthmind.memory.entity;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "ai_memory")
public class AiMemory {
    @Id @GeneratedValue
    private UUID id;
    @Column(name = "user_id", nullable = false)
    private UUID userId;
    @Column(name = "conversation_id")
    private UUID conversationId;
    @Column(nullable = false, length = 16)
    private String role;
    @Lob
    @Column(nullable = false)
    private String content;
    @Lob
    @Column(name = "metadata")
    private String metadata;
    @Column(name = "created_at", nullable = false)
    private Instant createdAt = Instant.now();
    @Column(name = "expires_at")
    private Instant expiresAt;

    public UUID getId() { return id; }
    public UUID getUserId() { return userId; }
    public UUID getConversationId() { return conversationId; }
    public String getRole() { return role; }
    public String getContent() { return content; }
    public String getMetadata() { return metadata; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getExpiresAt() { return expiresAt; }
    public void setUserId(UUID userId) { this.userId = userId; }
    public void setConversationId(UUID conversationId) { this.conversationId = conversationId; }
    public void setRole(String role) { this.role = role; }
    public void setContent(String content) { this.content = content; }
    public void setMetadata(String metadata) { this.metadata = metadata; }
    public void setExpiresAt(Instant expiresAt) { this.expiresAt = expiresAt; }
}
