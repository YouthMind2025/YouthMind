package ai.youthmind.memory.entity;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "user_preferences", uniqueConstraints = @UniqueConstraint(columnNames = {"user_id","pref_key"}))
public class UserPreference {
    @Id @GeneratedValue
    private UUID id;
    @Column(name = "user_id", nullable = false)
    private UUID userId;
    @Column(name = "pref_key", nullable = false, length = 64)
    private String key;
    @Lob
    @Column(name = "pref_value")
    private String value;
    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt = Instant.now();

    public UUID getId() { return id; }
    public UUID getUserId() { return userId; }
    public String getKey() { return key; }
    public String getValue() { return value; }
    public Instant getUpdatedAt() { return updatedAt; }
    public void setUserId(UUID userId) { this.userId = userId; }
    public void setKey(String key) { this.key = key; }
    public void setValue(String value) { this.value = value; this.updatedAt = Instant.now(); }
}
