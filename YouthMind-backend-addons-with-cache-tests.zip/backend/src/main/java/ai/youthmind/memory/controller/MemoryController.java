package ai.youthmind.memory.controller;

import ai.youthmind.memory.dto.ContextResponse;
import ai.youthmind.memory.dto.MemoryAppendRequest;
import ai.youthmind.memory.dto.PreferenceSetRequest;
import ai.youthmind.memory.entity.UserPreference;
import ai.youthmind.memory.service.MemoryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/memory")
@Tag(name = "Memory", description = "Persistent AI memory & preferences")
public class MemoryController {

    private final MemoryService service;

    public MemoryController(MemoryService service) { this.service = service; }

    @PostMapping("/append")
    @Operation(summary = "Append memory item")
    public ResponseEntity<Void> append(@RequestBody MemoryAppendRequest req) {
        service.append(req);
        return ResponseEntity.accepted().build();
    }

    @GetMapping("/context")
    @Operation(summary = "Get conversation context")
    public ResponseEntity<ContextResponse> context(@RequestParam UUID userId,
                                                   @RequestParam(required = false) UUID conversationId,
                                                   @RequestParam(defaultValue = "50") int limit) {
        return ResponseEntity.ok(service.context(userId, conversationId, limit));
    }

    @PostMapping("/pref/set")
    @Operation(summary = "Set user preference")
    public ResponseEntity<UserPreference> setPref(@RequestBody PreferenceSetRequest req) {
        return ResponseEntity.ok(service.setPref(req));
    }

    @GetMapping("/pref/get")
    @Operation(summary = "Get user preference")
    public ResponseEntity<UserPreference> getPref(@RequestParam UUID userId, @RequestParam String key) {
        UserPreference p = service.getPref(userId, key);
        return p == null ? ResponseEntity.notFound().build() : ResponseEntity.ok(p);
    }
}
