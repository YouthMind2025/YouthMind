package ai.youthmind.memory.dto;

import java.util.Map;
import java.util.UUID;

public class PreferenceSetRequest {
    public UUID userId;
    public String key;
    public Map<String,Object> value;
}
