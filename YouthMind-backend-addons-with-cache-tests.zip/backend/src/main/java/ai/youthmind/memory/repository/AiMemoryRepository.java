package ai.youthmind.memory.repository;

import ai.youthmind.memory.entity.AiMemory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

public interface AiMemoryRepository extends JpaRepository<AiMemory, UUID> {
    @Query("select m from AiMemory m where m.userId = :uid and (:cid is null or m.conversationId = :cid) and (m.expiresAt is null or m.expiresAt > :now) order by m.createdAt desc")
    List<AiMemory> fetchContext(@Param("uid") UUID userId, @Param("cid") UUID conversationId, @Param("now") Instant now);
}
