package ai.youthmind.memory.service;

import ai.youthmind.memory.dto.ContextResponse;
import ai.youthmind.memory.dto.MemoryAppendRequest;
import ai.youthmind.memory.dto.PreferenceSetRequest;
import ai.youthmind.memory.entity.AiMemory;
import ai.youthmind.memory.entity.UserPreference;
import ai.youthmind.memory.repository.AiMemoryRepository;
import ai.youthmind.memory.repository.UserPreferenceRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Service
public class MemoryService {

    private final AiMemoryRepository memRepo;
    private final UserPreferenceRepository prefRepo;
    private final ObjectMapper mapper = new ObjectMapper();

    public MemoryService(AiMemoryRepository memRepo, UserPreferenceRepository prefRepo) {
        this.memRepo = memRepo; this.prefRepo = prefRepo;
    }

    @Transactional
    public AiMemory append(MemoryAppendRequest req) {
        AiMemory m = new AiMemory();
        m.setUserId(req.userId); m.setConversationId(req.conversationId); m.setRole(req.role); m.setContent(req.content);
        m.setMetadata(writeJson(req.metadata));
        if (req.ttlSeconds != null && req.ttlSeconds > 0) m.setExpiresAt(Instant.now().plusSeconds(req.ttlSeconds));
        return memRepo.save(m);
    }

    public ContextResponse context(UUID userId, UUID conversationId, int limit) {
        List<AiMemory> rows = memRepo.fetchContext(userId, conversationId, Instant.now());
        List<ContextResponse.MemoryItem> items = rows.stream().limit(Math.max(1, Math.min(limit, 200)))
                .map(r -> new ContextResponse.MemoryItem(r.getRole(), r.getContent(), r.getMetadata(), r.getCreatedAt())).toList();
        return new ContextResponse(userId, conversationId, items, Instant.now());
    }

    @Transactional
    public UserPreference setPref(PreferenceSetRequest req) {
        UserPreference p = prefRepo.findByUserIdAndKey(req.userId, req.key).orElseGet(UserPreference::new);
        p.setUserId(req.userId); p.setKey(req.key); p.setValue(writeJson(req.value));
        return prefRepo.save(p);
    }

    public UserPreference getPref(UUID userId, String key) {
        return prefRepo.findByUserIdAndKey(userId, key).orElse(null);
    }

    private String writeJson(Object v) { try { return v==null? null : mapper.writeValueAsString(v);} catch (Exception e) { return null; } }
}
