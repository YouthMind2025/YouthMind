package ai.youthmind.memory.dto;

import java.util.Map;
import java.util.UUID;

public class MemoryAppendRequest {
    public UUID userId;
    public UUID conversationId;
    public String role;
    public String content;
    public Map<String,Object> metadata;
    public Long ttlSeconds;
}
