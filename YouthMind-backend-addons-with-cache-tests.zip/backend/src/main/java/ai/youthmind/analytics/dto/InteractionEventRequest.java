package ai.youthmind.analytics.dto;

import ai.youthmind.analytics.entity.UserBehaviorAnalytics;
import java.util.Map;
import java.util.UUID;

public class InteractionEventRequest {
    public UUID userId;
    public UUID postId;
    public UserBehaviorAnalytics.EventType type;
    public Map<String,Object> metadata;
}
