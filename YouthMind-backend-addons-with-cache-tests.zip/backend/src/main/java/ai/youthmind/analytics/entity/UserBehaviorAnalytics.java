package ai.youthmind.analytics.entity;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "user_behavior_analytics")
public class UserBehaviorAnalytics {
    @Id @GeneratedValue
    private UUID id;

    @Column(name = "user_id", nullable = false)
    private UUID userId;

    @Column(name = "post_id")
    private UUID postId;

    @Enumerated(EnumType.STRING)
    @Column(name = "event_type", nullable = false)
    private EventType eventType;

    @Column(name = "duration_ms")
    private Integer durationMs;

    @Lob
    @Column(name = "metadata")
    private String metadata;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt = Instant.now();

    public enum EventType { VIEW, LIKE, COMMENT, SAVE, SHARE, OTHER }

    public UUID getId() { return id; }
    public UUID getUserId() { return userId; }
    public UUID getPostId() { return postId; }
    public EventType getEventType() { return eventType; }
    public Integer getDurationMs() { return durationMs; }
    public String getMetadata() { return metadata; }
    public Instant getCreatedAt() { return createdAt; }
    public void setUserId(UUID userId) { this.userId = userId; }
    public void setPostId(UUID postId) { this.postId = postId; }
    public void setEventType(EventType eventType) { this.eventType = eventType; }
    public void setDurationMs(Integer durationMs) { this.durationMs = durationMs; }
    public void setMetadata(String metadata) { this.metadata = metadata; }
}
