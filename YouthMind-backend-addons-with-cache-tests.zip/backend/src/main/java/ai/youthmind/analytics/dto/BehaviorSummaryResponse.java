package ai.youthmind.analytics.dto;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

public class BehaviorSummaryResponse {
    public UUID userId;
    public int events;
    public long totalViewMs;
    public double avgViewMs;
    public Map<String, Long> interactions;
    public Map<String, Long> byDayOfWeek;
    public Instant generatedAt;

    public BehaviorSummaryResponse(UUID userId, int events, long totalViewMs, double avgViewMs,
                                   Map<String, Long> interactions, Map<String, Long> byDayOfWeek, Instant generatedAt) {
        this.userId = userId; this.events = events; this.totalViewMs = totalViewMs; this.avgViewMs = avgViewMs;
        this.interactions = interactions; this.byDayOfWeek = byDayOfWeek; this.generatedAt = generatedAt;
    }
}
