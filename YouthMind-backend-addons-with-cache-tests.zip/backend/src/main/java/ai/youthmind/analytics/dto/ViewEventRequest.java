package ai.youthmind.analytics.dto;

import java.util.Map;
import java.util.UUID;

public class ViewEventRequest {
    public UUID userId;
    public UUID postId;
    public Integer durationMs;
    public Map<String,Object> metadata;
}
