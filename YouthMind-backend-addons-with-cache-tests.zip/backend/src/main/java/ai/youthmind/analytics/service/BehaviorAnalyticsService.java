package ai.youthmind.analytics.service;

import ai.youthmind.analytics.dto.BehaviorSummaryResponse;
import ai.youthmind.analytics.dto.InteractionEventRequest;
import ai.youthmind.analytics.dto.ViewEventRequest;
import ai.youthmind.analytics.entity.UserBehaviorAnalytics;
import ai.youthmind.analytics.repository.UserBehaviorAnalyticsRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;

import java.time.*;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class BehaviorAnalyticsService {

    private final UserBehaviorAnalyticsRepository repo;
    private final ObjectMapper mapper = new ObjectMapper();

    public BehaviorAnalyticsService(UserBehaviorAnalyticsRepository repo) { this.repo = repo; }

    // Evict insights caches because new behavior may change analytics
    @CacheEvict(cacheNames = {"insights:wordcloud","insights:communication","insights:activity"}, key = "#req.userId")
    public void logView(ViewEventRequest req) {
        UserBehaviorAnalytics a = new UserBehaviorAnalytics();
        a.setUserId(req.userId); a.setPostId(req.postId);
        a.setEventType(UserBehaviorAnalytics.EventType.VIEW);
        a.setDurationMs(req.durationMs);
        a.setMetadata(toJson(req.metadata));
        repo.save(a);
    }

    @CacheEvict(cacheNames = {"insights:wordcloud","insights:communication","insights:activity"}, key = "#req.userId")
    public void logInteraction(InteractionEventRequest req) {
        UserBehaviorAnalytics a = new UserBehaviorAnalytics();
        a.setUserId(req.userId); a.setPostId(req.postId);
        a.setEventType(req.type == null ? UserBehaviorAnalytics.EventType.OTHER : req.type);
        a.setMetadata(toJson(req.metadata));
        repo.save(a);
    }

    public BehaviorSummaryResponse summarize(UUID userId, int days) {
        Instant since = Instant.now().minus(Duration.ofDays(days));
        List<UserBehaviorAnalytics> list = repo.findRecentByUser(userId, since);
        long totalView = list.stream().filter(e -> e.getEventType()== UserBehaviorAnalytics.EventType.VIEW && e.getDurationMs()!=null)
                .mapToLong(e -> e.getDurationMs()).sum();
        long viewCount = list.stream().filter(e -> e.getEventType()== UserBehaviorAnalytics.EventType.VIEW).count();
        double avgView = viewCount==0?0.0:(double) totalView / viewCount;

        Map<String, Long> interactions = list.stream()
                .filter(e -> e.getEventType()!= UserBehaviorAnalytics.EventType.VIEW)
                .collect(Collectors.groupingBy(e -> e.getEventType().name(), Collectors.counting()));
        Arrays.stream(UserBehaviorAnalytics.EventType.values())
                .forEach(t -> interactions.putIfAbsent(t.name(), 0L));

        Map<String, Long> byDow = new LinkedHashMap<>();
        for (DayOfWeek d : DayOfWeek.values()) byDow.put(d.name(), 0L);
        list.forEach(e -> {
            ZonedDateTime zdt = e.getCreatedAt().atZone(ZoneOffset.UTC);
            String key = zdt.getDayOfWeek().name();
            byDow.put(key, byDow.getOrDefault(key,0L)+1);
        });

        return new BehaviorSummaryResponse(userId, list.size(), totalView, avgView, interactions, byDow, Instant.now());
    }

    private String toJson(Map<String,Object> m) {
        try { return m==null? null : mapper.writeValueAsString(m); } catch (Exception e) { return null; }
    }
}
