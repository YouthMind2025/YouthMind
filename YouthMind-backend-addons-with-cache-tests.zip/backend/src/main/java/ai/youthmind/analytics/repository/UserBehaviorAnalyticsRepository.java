package ai.youthmind.analytics.repository;

import ai.youthmind.analytics.entity.UserBehaviorAnalytics;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

public interface UserBehaviorAnalyticsRepository extends JpaRepository<UserBehaviorAnalytics, UUID> {
    @Query("select a from UserBehaviorAnalytics a where a.userId = :uid and a.createdAt >= :since")
    List<UserBehaviorAnalytics> findRecentByUser(@Param("uid") UUID userId, @Param("since") Instant since);
}
