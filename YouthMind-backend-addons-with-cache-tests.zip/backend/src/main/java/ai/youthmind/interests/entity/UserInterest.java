package ai.youthmind.interests.entity;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "user_interests", uniqueConstraints = @UniqueConstraint(columnNames = {"user_id","topic"}))
public class UserInterest {
    @Id @GeneratedValue
    private UUID id;
    @Column(name = "user_id", nullable = false)
    private UUID userId;
    @Column(nullable = false, length = 100)
    private String topic;
    @Column(nullable = false)
    private double score;
    @Column(name = "decayed_score", nullable = false)
    private double decayedScore;
    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt = Instant.now();

    public UUID getId() { return id; }
    public UUID getUserId() { return userId; }
    public String getTopic() { return topic; }
    public double getScore() { return score; }
    public double getDecayedScore() { return decayedScore; }
    public Instant getUpdatedAt() { return updatedAt; }
    public void setUserId(UUID userId) { this.userId = userId; }
    public void setTopic(String topic) { this.topic = topic; }
    public void setScore(double score) { this.score = score; }
    public void setDecayedScore(double decayedScore) { this.decayedScore = decayedScore; }
    public void setUpdatedAt(Instant updatedAt) { this.updatedAt = updatedAt; }
}
