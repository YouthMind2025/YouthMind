package ai.youthmind.interests.repository;

import ai.youthmind.interests.entity.UserInterest;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface UserInterestRepository extends JpaRepository<UserInterest, UUID> {
    List<UserInterest> findByUserIdOrderByDecayedScoreDesc(UUID userId);
    Optional<UserInterest> findByUserIdAndTopic(UUID userId, String topic);
}
