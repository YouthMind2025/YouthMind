package ai.youthmind.interests.controller;

import ai.youthmind.interests.entity.UserInterest;
import ai.youthmind.interests.service.InterestService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/interests")
@Tag(name = "Interests", description = "User interests & recommendations")
public class InterestController {

    private final InterestService service;

    public InterestController(InterestService service) { this.service = service; }

    @PostMapping("/recompute/{userId}")
    @Operation(summary = "Recompute interests from user's posts")
    public ResponseEntity<List<UserInterest>> recompute(@PathVariable UUID userId,
                                                        @RequestParam(defaultValue = "20") int top) {
        return ResponseEntity.ok(service.recompute(userId, top));
        }

    @GetMapping("/{userId}")
    @Operation(summary = "List user's interests")
    public ResponseEntity<List<UserInterest>> list(@PathVariable UUID userId) {
        return ResponseEntity.ok(service.list(userId));
    }

    @GetMapping("/{userId}/recommendations")
    @Operation(summary = "Recommend posts based on interests")
    public ResponseEntity<java.util.List<ai.youthmind.interests.service.InterestService.Recommendation>> recs(@PathVariable UUID userId,
                                                                                                    @RequestParam(defaultValue = "20") int limit) {
        return ResponseEntity.ok(service.recommend(userId, limit));
    }
}
