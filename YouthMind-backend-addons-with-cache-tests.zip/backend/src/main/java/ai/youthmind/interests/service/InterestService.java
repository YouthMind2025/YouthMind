package ai.youthmind.interests.service;

import ai.youthmind.interests.entity.UserInterest;
import ai.youthmind.interests.repository.UserInterestRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class InterestService {

    private final UserInterestRepository repo;
    @PersistenceContext private EntityManager em;

    private static final Pattern WORD = Pattern.compile("[\\p{L}]{3,}");
    private static final Set<String> STOP = Set.of("the","and","for","with","this","that","your","from","have","about","into","there","were","been","what","when","where","كيف","هذا","هذه","على","الى","في");

    public InterestService(UserInterestRepository repo) { this.repo = repo; }

    @Transactional
    @CacheEvict(cacheNames = {"insights:wordcloud","insights:communication","insights:activity"}, key = "#userId")
    public List<UserInterest> recompute(UUID userId, int top) {
        List<String> texts = loadUserPosts(userId);
        Map<String,Integer> freq = new HashMap<>();
        for (String t : texts) for (String w : tokenize(t)) freq.merge(w,1,Integer::sum);
        List<Map.Entry<String,Integer>> sorted = freq.entrySet().stream()
                .sorted((a,b)-> Integer.compare(b.getValue(), a.getValue()))
                .limit(Math.max(5, Math.min(top, 50))).toList();
        double max = sorted.isEmpty()?1:sorted.get(0).getValue();
        List<UserInterest> out = new ArrayList<>();
        for (Map.Entry<String,Integer> e : sorted) {
            double score = e.getValue();
            double decayed = score; // hook: apply time decay later
            UserInterest ui = repo.findByUserIdAndTopic(userId, e.getKey()).orElseGet(UserInterest::new);
            ui.setUserId(userId); ui.setTopic(e.getKey()); ui.setScore(score); ui.setDecayedScore(decayed); ui.setUpdatedAt(Instant.now());
            out.add(repo.save(ui));
        }
        return out;
    }

    public List<UserInterest> list(UUID userId) {
        return repo.findByUserIdOrderByDecayedScoreDesc(userId);
    }

    public List<Recommendation> recommend(UUID userId, int limit) {
        List<UserInterest> interests = list(userId);
        if (interests.isEmpty()) return List.of();
        List<String> topics = interests.stream().limit(10).map(UserInterest::getTopic).toList();
        List<Object[]> rows = searchPostsByKeywords(userId, topics, limit*3);
        List<Recommendation> recs = new ArrayList<>();
        for (Object[] r : rows) {
            UUID postId = (UUID) r[0];
            String content = (String) r[1];
            double score = 0.0;
            for (UserInterest ui : interests) {
                int hits = countOccurrences(content.toLowerCase(Locale.ROOT), ui.getTopic().toLowerCase(Locale.ROOT));
                score += hits * ui.getDecayedScore();
            }
            if (score > 0) recs.add(new Recommendation(postId, score));
        }
        recs.sort((a,b)-> Double.compare(b.score, a.score));
        return recs.stream().limit(limit).toList();
    }

    private List<String> loadUserPosts(UUID userId) {
        Query q = em.createNativeQuery("SELECT content FROM posts WHERE user_id = :u");
        q.setParameter("u", userId);
        @SuppressWarnings("unchecked") List<String> res = q.getResultList();
        return res;
    }

    private List<Object[]> searchPostsByKeywords(UUID userId, List<String> keywords, int limit) {
        String like = String.join("|", keywords);
        Query q = em.createNativeQuery("SELECT id, content FROM posts WHERE user_id <> :u AND LOWER(content) ~ :re ORDER BY created_at DESC LIMIT :lim");
        q.setParameter("u", userId);
        q.setParameter("re", like.toLowerCase(Locale.ROOT));
        q.setParameter("lim", limit);
        @SuppressWarnings("unchecked") List<Object[]> rows = q.getResultList();
        return rows;
    }

    private static List<String> tokenize(String t) {
        List<String> out = new ArrayList<>();
        if (t==null) return out;
        Matcher m = WORD.matcher(t.toLowerCase(Locale.ROOT));
        while (m.find()) { String w = m.group(); if (!STOP.contains(w)) out.add(w); }
        return out;
    }

    private static int countOccurrences(String hay, String needle) {
        int c=0, idx=0; while ((idx = hay.indexOf(needle, idx)) >=0) { c++; idx += needle.length(); } return c;
    }

    public record Recommendation(UUID postId, double score) {}
}
