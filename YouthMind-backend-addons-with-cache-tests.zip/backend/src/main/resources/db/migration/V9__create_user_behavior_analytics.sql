-- V9__create_user_behavior_analytics.sql
-- Tracks user behavior events for analytics
CREATE TABLE IF NOT EXISTS user_behavior_analytics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL,
    post_id UUID,
    event_type VARCHAR(32) NOT NULL,
    duration_ms INTEGER,
    metadata JSONB,
    created_at TIMESTAMP NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_uba_user ON user_behavior_analytics(user_id);
CREATE INDEX IF NOT EXISTS idx_uba_post ON user_behavior_analytics(post_id);
CREATE INDEX IF NOT EXISTS idx_uba_event ON user_behavior_analytics(event_type);
CREATE INDEX IF NOT EXISTS idx_uba_created ON user_behavior_analytics(created_at);
