-- V11__create_ai_memory_and_preferences.sql
-- Memory store and user preferences
CREATE TABLE IF NOT EXISTS ai_memory (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL,
    conversation_id UUID,
    role VARCHAR(16) NOT NULL,
    content TEXT NOT NULL,
    metadata JSONB,
    created_at TIMESTAMP NOT NULL DEFAULT now(),
    expires_at TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_mem_user ON ai_memory(user_id);
CREATE INDEX IF NOT EXISTS idx_mem_conv ON ai_memory(conversation_id);
CREATE INDEX IF NOT EXISTS idx_mem_created ON ai_memory(created_at);

CREATE TABLE IF NOT EXISTS user_preferences (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL,
    pref_key VARCHAR(64) NOT NULL,
    pref_value JSONB,
    updated_at TIMESTAMP NOT NULL DEFAULT now(),
    UNIQUE (user_id, pref_key)
);
CREATE INDEX IF NOT EXISTS idx_prefs_user ON user_preferences(user_id);
