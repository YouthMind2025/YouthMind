-- V10__create_user_interests.sql
-- Stores derived user interests topics and scores
CREATE TABLE IF NOT EXISTS user_interests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL,
    topic VARCHAR(100) NOT NULL,
    score DOUBLE PRECISION NOT NULL DEFAULT 0,
    decayed_score DOUBLE PRECISION NOT NULL DEFAULT 0,
    updated_at TIMESTAMP NOT NULL DEFAULT now(),
    UNIQUE (user_id, topic)
);
CREATE INDEX IF NOT EXISTS idx_ui_user ON user_interests(user_id);
CREATE INDEX IF NOT EXISTS idx_ui_score ON user_interests(decayed_score);
