# YouthMind Add-ons: Behavior, Interests, Memory

## Cache eviction hooks
- Behavior events (`/api/behavior/view`, `/api/behavior/interaction`) evict `insights:wordcloud`, `insights:communication`, `insights:activity` for the affected user.
- Interest recompute (`/api/interests/recompute/{userId}`) also evicts those caches.

## Testing with Testcontainers
Integration tests are under `backend/src/test/java/...` and use a PostgreSQL Testcontainer.
Add these to your `pom.xml`:

```xml
<dependency>
  <groupId>org.testcontainers</groupId>
  <artifactId>junit-jupiter</artifactId>
  <version>1.19.7</version>
  <scope>test</scope>
</dependency>
<dependency>
  <groupId>org.testcontainers</groupId>
  <artifactId>postgresql</artifactId>
  <version>1.19.7</version>
  <scope>test</scope>
</dependency>
```

Also ensure you have Spring Boot Test dependencies and Flyway.

Run tests:
```bash
mvn -Dspring.profiles.active=test -DskipITs=false test
```

## Endpoints
- Behavior: `POST /api/behavior/view`, `POST /api/behavior/interaction`, `GET /api/behavior/summary/{userId}?days=30`
- Interests: `POST /api/interests/recompute/{userId}`, `GET /api/interests/{userId}`, `GET /api/interests/{userId}/recommendations?limit=20`
- Memory: `POST /api/memory/append`, `GET /api/memory/context?userId=...&conversationId=...`, `POST /api/memory/pref/set`, `GET /api/memory/pref/get?userId=...&key=...`
