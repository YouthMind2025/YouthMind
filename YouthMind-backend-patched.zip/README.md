# YouthMind Backend (Patched)

Runnable Spring Boot 3.3.3 backend with psychology layer, caches, safety filter, async/scheduling, circuit breaker, and optional Redis.

## Run
```bash
cd backend
mvn -q -DskipTests spring-boot:run
```

## Smoke
```bash
curl -s localhost:8080/actuator/health
curl -s -X POST localhost:8080/api/ai/chat/reply/demo -H 'Content-Type: application/json' -d '{"message":"I feel anxious"}'
curl -s localhost:8080/api/psychology/state/demo
```

## Notes
- Redis disabled by default. Enable via `app.redis.enabled=true`.
- CORS allows localhost tools.
- Security is conditional; if you have your own `SecurityFilterChain`, ensure it permits `/api/ai/**`, `/api/psychology/**`, `/actuator/health`.
