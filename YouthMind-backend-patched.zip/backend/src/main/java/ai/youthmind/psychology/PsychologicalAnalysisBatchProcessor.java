package ai.youthmind.psychology;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class PsychologicalAnalysisBatchProcessor {
    private final StateUpdateQueue queue;
    private final PsychologicalStateCache cache;

    public PsychologicalAnalysisBatchProcessor(StateUpdateQueue queue, PsychologicalStateCache cache) {
        this.queue = queue;
        this.cache = cache;
    }

    @Scheduled(fixedDelay = 2000)
    public void processBatch() {
        List<PsychologicalState> batch = new ArrayList<>();
        int n = queue.drainTo(batch, 100);
        if (n <= 0) return;
        for (PsychologicalState s : batch) {
            cache.put(s.userId(), s.factors());
        }
    }
}
