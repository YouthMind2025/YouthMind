package ai.youthmind.psychology;

import org.springframework.stereotype.Component;

public interface SafetyFilter {
    boolean isAllowed(String userId, String message);
}

@Component
class PsychologicalSafetyFilter implements SafetyFilter {
    private final PsychologicalStateCache cache;

    public PsychologicalSafetyFilter(PsychologicalStateCache cache) {
        this.cache = cache;
    }

    @Override
    public boolean isAllowed(String userId, String message) {
        String m = message == null ? "" : message.toLowerCase();
        PsychologicalState st = cache.get(userId);
        double stress = st == null ? 0.3 : st.get("stress", 0.3);
        if (stress > 0.7 && (m.contains("self-harm") || m.contains("suicide"))) return false;
        return true;
    }
}
