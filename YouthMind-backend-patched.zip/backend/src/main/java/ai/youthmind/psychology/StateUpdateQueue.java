package ai.youthmind.psychology;

import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

@Component
public class StateUpdateQueue {
    private final BlockingQueue<PsychologicalState> queue = new LinkedBlockingQueue<>(1000);

    public void enqueue(PsychologicalState s) { queue.offer(s); }

    public PsychologicalState take() throws InterruptedException { return queue.take(); }

    public int size() { return queue.size(); }

    public int drainTo(Collection<? super PsychologicalState> target, int maxElements) {
        return queue.drainTo(target, maxElements);
    }
}
