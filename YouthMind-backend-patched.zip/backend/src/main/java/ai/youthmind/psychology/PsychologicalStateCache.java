package ai.youthmind.psychology;

import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class PsychologicalStateCache {
    private final CacheManager cacheManager;
    private volatile Cache cache;
    private final Map<String, Instant> expiries = new ConcurrentHashMap<>();
    private static final Duration TTL = Duration.ofMinutes(10);

    public PsychologicalStateCache(CacheManager cacheManager) {
        this.cacheManager = cacheManager;
        this.cache = ensureCache("psychologicalState");
    }

    private Cache ensureCache(String name) {
        Cache c = cacheManager.getCache(name);
        if (c == null && cacheManager instanceof org.springframework.cache.caffeine.CaffeineCacheManager cm) {
            cm.getCache(name);
            c = cacheManager.getCache(name);
        }
        return c;
    }

    public void put(String userId, Map<String, Double> factors) {
        if (cache == null) cache = ensureCache("psychologicalState");
        if (cache == null) return;
        PsychologicalState state = new PsychologicalState(userId, factors, Instant.now());
        cache.put(userId, state);
        expiries.put(userId, Instant.now().plus(TTL));
    }

    public PsychologicalState get(String userId) {
        if (cache == null) cache = ensureCache("psychologicalState");
        if (cache == null) return null;
        Instant exp = expiries.get(userId);
        if (exp != null && exp.isBefore(Instant.now())) {
            invalidate(userId);
            return null;
        }
        Cache.ValueWrapper v = cache.get(userId);
        return v == null ? null : (PsychologicalState) v.get();
    }

    public void invalidate(String userId) {
        if (cache == null) cache = ensureCache("psychologicalState");
        if (cache != null) cache.evict(userId);
        expiries.remove(userId);
    }

    public void invalidateAll() {
        expiries.keySet().forEach(this::invalidate);
    }
}
