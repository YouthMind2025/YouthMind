package ai.youthmind.psychology;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

@Service
public class AIChatService {
    private final PsychologicalStateCache stateCache;
    private final BuddhistFactorCache factorCache;
    private final StateUpdateQueue queue;

    public AIChatService(PsychologicalStateCache stateCache, BuddhistFactorCache factorCache, StateUpdateQueue queue) {
        this.stateCache = stateCache;
        this.factorCache = factorCache;
        this.queue = queue;
    }

    @CircuitBreaker(name = "aiChat", fallbackMethod = "fallbackResponse")
    public Map<String, Object> generateResponse(String userId, String userMessage) {
        PsychologicalState state = stateCache.get(userId);
        Map<String, Double> weights = factorCache.get("default");
        double stress = state == null ? 0.3 : state.get("stress", 0.3);
        double mindfulness = (state == null ? 0.5 : state.get("mindfulness", 0.5))
                * weights.getOrDefault("mindfulness", 0.4);
        double compassion = (state == null ? 0.5 : state.get("compassion", 0.5))
                * weights.getOrDefault("compassion", 0.3);

        String tone = stress > 0.6 ? "calming" : (mindfulness > 0.6 ? "reflective" : "neutral");
        String reply = switch (tone) {
            case "calming" -> "I hear you. Let's take a slow breath together. What feels most heavy right now?";
            case "reflective" -> "Let’s observe the thought gently. What changes if we sit with it for a moment?";
            default -> "Thanks for sharing. Tell me more so I can help.";
        };

        Map<String, Object> out = new HashMap<>();
        out.put("reply", reply);
        out.put("tone", tone);
        out.put("psychology", Map.of(
                "stress", stress,
                "mindfulness", mindfulness,
                "compassion", compassion
        ));
        return out;
    }

    public Map<String, Object> fallbackResponse(String userId, String userMessage, Throwable t) {
        Map<String, Object> out = new HashMap<>();
        out.put("reply", "I'm here with you. If things feel tough, consider a brief pause and a glass of water.");
        out.put("tone", "supportive");
        out.put("psychology", Map.of());
        out.put("fallback", true);
        return out;
    }

    @Async
    public CompletableFuture<Void> analyzeAndUpdateState(String userId, String message) {
        final String m = message == null ? "" : message.toLowerCase();
        double stress = (m.contains("anxious") || m.contains("panic") || m.contains("overwhelmed")) ? 0.75 : 0.3;
        Map<String, Double> factors = new HashMap<>();
        factors.put("stress", stress);
        factors.put("mindfulness", 0.5);
        factors.put("compassion", 0.6);
        PsychologicalState state = new PsychologicalState(userId, factors, java.time.Instant.now());
        queue.enqueue(state);
        stateCache.put(userId, factors);
        return CompletableFuture.completedFuture(null);
    }
}
