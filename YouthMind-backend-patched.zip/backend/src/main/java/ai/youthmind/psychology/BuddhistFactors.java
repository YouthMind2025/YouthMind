package ai.youthmind.psychology;

import java.util.Map;

public record BuddhistFactors(Map<String, Double> weights) {
    public double weight(String key, double def) { return weights.getOrDefault(key, def); }
}
