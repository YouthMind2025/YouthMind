package ai.youthmind.psychology;

import java.time.Instant;
import java.util.Map;

public record PsychologicalState(
        String userId,
        Map<String, Double> factors,
        Instant updatedAt
) {
    public double get(String key, double def) { return factors.getOrDefault(key, def); }
}
