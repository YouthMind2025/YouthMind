package ai.youthmind.psychology;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.Map;

@RestController
@RequestMapping("/api/psychology")
@CrossOrigin
public class PsychologyController {
    private final PsychologicalStateCache cache;

    public PsychologyController(PsychologicalStateCache cache) {
        this.cache = cache;
    }

    @GetMapping("/state/{userId}")
    public ResponseEntity<PsychologicalState> getState(@PathVariable String userId) {
        PsychologicalState st = cache.get(userId);
        if (st == null) {
            st = new PsychologicalState(userId, Map.of(), (Instant) null);
        }
        return ResponseEntity.ok(st);
    }
}
