package ai.youthmind.psychology;

import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class PersonalityProfileCache {
    private final CacheManager cacheManager;
    private volatile Cache cache;

    public PersonalityProfileCache(CacheManager cacheManager) {
        this.cacheManager = cacheManager;
        this.cache = ensureCache("personalityProfile");
    }

    private Cache ensureCache(String name) {
        Cache c = cacheManager.getCache(name);
        if (c == null && cacheManager instanceof org.springframework.cache.caffeine.CaffeineCacheManager cm) {
            cm.getCache(name);
            c = cacheManager.getCache(name);
        }
        return c;
    }

    public void put(String userId, Map<String, Object> profile) {
        if (cache == null) cache = ensureCache("personalityProfile");
        if (cache != null) cache.put(userId, profile);
    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> get(String userId) {
        if (cache == null) cache = ensureCache("personalityProfile");
        if (cache == null) return null;
        Cache.ValueWrapper v = cache.get(userId);
        return v == null ? null : (Map<String, Object>) v.get();
    }

    @Scheduled(fixedDelay = 300_000)
    public void warm() { /* no-op */ }
}
