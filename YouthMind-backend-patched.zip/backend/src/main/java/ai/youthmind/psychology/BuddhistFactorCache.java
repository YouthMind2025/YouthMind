package ai.youthmind.psychology;

import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class BuddhistFactorCache {
    private final CacheManager cacheManager;
    private volatile Cache cache;

    public BuddhistFactorCache(CacheManager cacheManager) {
        this.cacheManager = cacheManager;
        this.cache = ensureCache("buddhistFactors");
        if (cache != null && cache.get("default") == null) {
            cache.put("default", Map.of(
                    "mindfulness", 0.4,
                    "compassion", 0.3,
                    "equanimity", 0.2,
                    "nonAttachment", 0.1
            ));
        }
    }

    private Cache ensureCache(String name) {
        Cache c = cacheManager.getCache(name);
        if (c == null && cacheManager instanceof org.springframework.cache.caffeine.CaffeineCacheManager cm) {
            cm.getCache(name);
            c = cacheManager.getCache(name);
        }
        return c;
    }

    @SuppressWarnings("unchecked")
    public Map<String, Double> get(String key) {
        if (cache == null) cache = ensureCache("buddhistFactors");
        if (cache == null) return Map.of();
        Cache.ValueWrapper v = cache.get(key);
        return v == null ? Map.of() : (Map<String, Double>) v.get();
    }

    public void put(String key, Map<String, Double> weights) {
        if (cache == null) cache = ensureCache("buddhistFactors");
        if (cache != null) cache.put(key, weights);
    }
}
