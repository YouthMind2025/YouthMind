package ai.youthmind.psychology;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/ai/chat")
@CrossOrigin
public class AIChatController {
    private final AIChatService service;
    private final SafetyFilter safety;

    public AIChatController(AIChatService service, SafetyFilter safety) {
        this.service = service;
        this.safety = safety;
    }

    @PostMapping("/reply/{userId}")
    public ResponseEntity<Map<String, Object>> reply(@PathVariable String userId, @RequestBody(required = false) Map<String, String> payload) {
        String msg = payload == null ? "" : payload.getOrDefault("message", "");
        if (!safety.isAllowed(userId, msg)) {
            return ResponseEntity.status(403).body(Map.of("error", "content_restricted"));
        }
        Map<String, Object> response = service.generateResponse(userId, msg);
        service.analyzeAndUpdateState(userId, msg);
        return ResponseEntity.ok(response);
    }
}
