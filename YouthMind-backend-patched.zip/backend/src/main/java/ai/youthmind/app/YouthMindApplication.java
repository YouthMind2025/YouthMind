package ai.youthmind.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "ai.youthmind")
public class YouthMindApplication {
    public static void main(String[] args) {
        SpringApplication.run(YouthMindApplication.class, args);
    }
}
