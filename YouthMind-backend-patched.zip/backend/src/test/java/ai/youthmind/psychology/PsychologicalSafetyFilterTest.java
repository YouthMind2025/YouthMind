package ai.youthmind.psychology;

import org.junit.jupiter.api.Test;
import org.springframework.cache.CacheManager;
import org.springframework.cache.caffeine.CaffeineCacheManager;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class PsychologicalSafetyFilterTest {

    private PsychologicalStateCache cache() {
        CacheManager cm = new CaffeineCacheManager();
        return new PsychologicalStateCache(cm);
    }

    @Test
    void highStress_blocksSelfHarm() {
        var c = cache();
        c.put("u3", Map.of("stress", 0.8));
        var filter = new PsychologicalSafetyFilter(c);
        assertFalse(filter.isAllowed("u3", "thoughts about self-harm"));
    }

    @Test
    void lowStress_allowsGeneral() {
        var c = cache();
        c.put("u4", Map.of("stress", 0.2));
        var filter = new PsychologicalSafetyFilter(c);
        assertTrue(filter.isAllowed("u4", "random chat"));
    }
}
