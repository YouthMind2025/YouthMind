package ai.youthmind.psychology;

import org.junit.jupiter.api.Test;
import org.springframework.cache.CacheManager;
import org.springframework.cache.caffeine.CaffeineCacheManager;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class AIChatServiceTest {

    private PsychologicalStateCache newStateCache() {
        CacheManager cm = new CaffeineCacheManager();
        return new PsychologicalStateCache(cm);
    }

    private BuddhistFactorCache newFactorCache() {
        CacheManager cm = new CaffeineCacheManager();
        return new BuddhistFactorCache(cm);
    }

    @Test
    void generateResponse_returnsToneAndReply() {
        var stateCache = newStateCache();
        var factorCache = newFactorCache();
        var queue = new StateUpdateQueue();

        Map<String, Double> factors = new HashMap<>();
        factors.put("stress", 0.2);
        factors.put("mindfulness", 0.7);
        factors.put("compassion", 0.6);
        stateCache.put("u1", factors);

        var svc = new AIChatService(stateCache, factorCache, queue);
        var out = svc.generateResponse("u1", "Hello!");
        assertNotNull(out.get("reply"));
        assertNotNull(out.get("tone"));
        String tone = (String) out.get("tone");
        assertTrue(tone.equals("reflective") || tone.equals("neutral") || tone.equals("calming"));
    }

    @Test
    void analyzeAndUpdateState_updatesStress() {
        var stateCache = newStateCache();
        var factorCache = newFactorCache();
        var queue = new StateUpdateQueue();
        var svc = new AIChatService(stateCache, factorCache, queue);

        svc.analyzeAndUpdateState("u2", "I feel anxious and overwhelmed");
        var st = stateCache.get("u2");
        assertNotNull(st);
        assertTrue(st.get("stress", 0) >= 0.7);
    }
}
