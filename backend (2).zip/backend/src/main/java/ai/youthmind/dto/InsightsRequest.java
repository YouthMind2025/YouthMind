package ai.youthmind.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InsightsRequest {
    private LocalDateTime start;
    private LocalDateTime end;

    @Override
    public String toString() {
        return start + " - " + end;
    }
}
