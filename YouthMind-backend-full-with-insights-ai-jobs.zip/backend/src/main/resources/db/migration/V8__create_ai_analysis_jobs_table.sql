-- Tracks background AI analysis job status per post
CREATE TABLE IF NOT EXISTS ai_analysis_jobs (
    id UUID DEFAULT RANDOM_UUID() PRIMARY KEY,
    post_id UUID NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'PENDING',
    error TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_ai_jobs_post FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_ai_jobs_post ON ai_analysis_jobs(post_id);
CREATE INDEX IF NOT EXISTS idx_ai_jobs_status ON ai_analysis_jobs(status);
