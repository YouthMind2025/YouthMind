package ai.youthmind.ai;

import java.util.UUID;

public class AiAnalysisJobStatusResponse {
    public UUID postId;
    public AiAnalysisJobDTO latestJob;
    public long historyCount;

    public AiAnalysisJobStatusResponse(UUID postId, AiAnalysisJobDTO latestJob, long historyCount) {
        this.postId = postId; this.latestJob = latestJob; this.historyCount = historyCount;
    }
}
