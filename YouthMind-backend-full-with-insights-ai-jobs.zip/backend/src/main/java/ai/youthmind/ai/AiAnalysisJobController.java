package ai.youthmind.ai;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/ai-analysis/jobs")
@Tag(name = "AI Analysis Jobs", description = "Query & control AI analysis jobs")
public class AiAnalysisJobController {

    private final AiAnalysisJobService service;

    public AiAnalysisJobController(AiAnalysisJobService service) { this.service = service; }

    @GetMapping("/status")
    @Operation(summary = "Get latest job status for a post")
    public ResponseEntity<AiAnalysisJobStatusResponse> status(@RequestParam UUID postId) {
        return ResponseEntity.ok(service.latestByPostId(postId));
    }

    @PostMapping("/retrigger")
    @Operation(summary = "Retrigger analysis for a post (creates a new job)")
    public ResponseEntity<AiAnalysisJobDTO> retrigger(@RequestParam UUID postId) {
        return ResponseEntity.ok(service.retrigger(postId));
    }

    @GetMapping("/failed")
    @Operation(summary = "Paginated failed jobs with optional filters (from/to/postId/userId)")
    public ResponseEntity<AiAnalysisJobPageResponse> failedPaged(@RequestParam(required = false) Integer page,
                                                                 @RequestParam(required = false) Integer size,
                                                                 @RequestParam(required = false) Instant from,
                                                                 @RequestParam(required = false) Instant to,
                                                                 @RequestParam(required = false) UUID postId,
                                                                 @RequestParam(required = false) UUID userId) {
        return ResponseEntity.ok(service.failedPaged(page, size, from, to, postId, userId));
    }

    @GetMapping("/failed/quick")
    @Operation(summary = "List recent failed jobs quickly (no filters)")
    public ResponseEntity<List<AiAnalysisJobDTO>> failedQuick(@RequestParam(name = "limit", defaultValue = "20") int limit) {
        return ResponseEntity.ok(service.recentFailed(limit));
    }
}
