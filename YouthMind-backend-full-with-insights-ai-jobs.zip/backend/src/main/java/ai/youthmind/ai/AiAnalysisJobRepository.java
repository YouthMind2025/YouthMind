package ai.youthmind.ai;

import ai.youthmind.entity.AiAnalysisJob;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface AiAnalysisJobRepository extends JpaRepository<AiAnalysisJob, UUID> {
    Optional<AiAnalysisJob> findFirstByPostIdOrderByUpdatedAtDesc(UUID postId);
    long countByPostId(UUID postId);
    List<AiAnalysisJob> findByStatusOrderByUpdatedAtDesc(AiAnalysisJob.Status status, Pageable pageable);
}
