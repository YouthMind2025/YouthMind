package ai.youthmind.ai;

import ai.youthmind.entity.AiAnalysisJob;

import java.time.Instant;
import java.util.UUID;

public class AiAnalysisJobDTO {
    public UUID id;
    public UUID postId;
    public String status;
    public String error;
    public Instant createdAt;
    public Instant updatedAt;

    public static AiAnalysisJobDTO from(AiAnalysisJob j) {
        AiAnalysisJobDTO d = new AiAnalysisJobDTO();
        d.id = j.getId();
        d.postId = j.getPostId();
        d.status = j.getStatus().name();
        d.error = j.getError();
        d.createdAt = j.getCreatedAt();
        d.updatedAt = j.getUpdatedAt();
        return d;
    }
}
