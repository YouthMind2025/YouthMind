package ai.youthmind.ai;

import ai.youthmind.entity.AiAnalysisJob;
import ai.youthmind.service.AIAnalysisService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.*;

@Service
public class AiAnalysisJobService {

    private final AiAnalysisJobRepository repo;
    private final AIAnalysisService aiAnalysisService;

    @PersistenceContext
    private EntityManager em;

    public AiAnalysisJobService(AiAnalysisJobRepository repo, AIAnalysisService aiAnalysisService) {
        this.repo = repo;
        this.aiAnalysisService = aiAnalysisService;
    }

    public AiAnalysisJobStatusResponse latestByPostId(UUID postId) {
        AiAnalysisJob job = repo.findFirstByPostIdOrderByUpdatedAtDesc(postId).orElse(null);
        long count = repo.countByPostId(postId);
        return new AiAnalysisJobStatusResponse(postId, job == null ? null : AiAnalysisJobDTO.from(job), count);
    }

    public List<AiAnalysisJobDTO> recentFailed(int limit) {
        return repo.findByStatusOrderByUpdatedAtDesc(AiAnalysisJob.Status.FAILED, PageRequest.of(0, Math.max(1, Math.min(limit, 100))))
                .stream().map(AiAnalysisJobDTO::from).toList();
    }

    @Transactional
    public AiAnalysisJobDTO retrigger(UUID postId) {
        AiAnalysisJob job = aiAnalysisService.triggerAsyncAnalysis(postId);
        return AiAnalysisJobDTO.from(job);
    }

    public AiAnalysisJobPageResponse failedPaged(Integer page, Integer size, Instant from, Instant to, UUID postId, UUID userId) {
        int p = page == null ? 0 : Math.max(0, page);
        int s = size == null ? 20 : Math.max(1, Math.min(size, 200));

        StringBuilder sql = new StringBuilder("SELECT j.* FROM ai_analysis_jobs j");
        StringBuilder count = new StringBuilder("SELECT COUNT(*) FROM ai_analysis_jobs j");
        List<String> where = new ArrayList<>();
        if (userId != null) {
            sql.append(" JOIN posts p ON p.id = j.post_id");
            count.append(" JOIN posts p ON p.id = j.post_id");
            where.add("p.user_id = :userId");
        }
        if (postId != null) where.add("j.post_id = :postId");
        if (from != null) where.add("j.updated_at >= :from");
        if (to != null) where.add("j.updated_at <= :to");
        where.add("j.status = 'FAILED'");

        if (!where.isEmpty()) {
            String w = String.join(" AND ", where);
            sql.append(" WHERE ").append(w);
            count.append(" WHERE ").append(w);
        }
        sql.append(" ORDER BY j.updated_at DESC");

        Query q = em.createNativeQuery(sql.toString(), AiAnalysisJob.class);
        Query qc = em.createNativeQuery(count.toString());

        if (userId != null) { q.setParameter("userId", userId); qc.setParameter("userId", userId); }
        if (postId != null) { q.setParameter("postId", postId); qc.setParameter("postId", postId); }
        if (from != null) { q.setParameter("from", from); qc.setParameter("from", from); }
        if (to != null) { q.setParameter("to", to); qc.setParameter("to", to); }

        q.setFirstResult(p * s);
        q.setMaxResults(s);

        @SuppressWarnings("unchecked")
        List<AiAnalysisJob> rows = q.getResultList();
        long total = ((Number) qc.getSingleResult()).longValue();

        List<AiAnalysisJobDTO> content = rows.stream().map(AiAnalysisJobDTO::from).toList();
        return new AiAnalysisJobPageResponse(content, p, s, total);
    }
}
