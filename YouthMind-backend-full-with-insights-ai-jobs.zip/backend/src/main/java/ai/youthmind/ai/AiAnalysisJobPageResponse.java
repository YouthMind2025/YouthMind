package ai.youthmind.ai;

import java.util.List;

public class AiAnalysisJobPageResponse {
    public List<AiAnalysisJobDTO> content;
    public int page;
    public int size;
    public long totalElements;
    public int totalPages;
    public boolean hasNext;

    public AiAnalysisJobPageResponse(List<AiAnalysisJobDTO> content, int page, int size, long totalElements) {
        this.content = content;
        this.page = page;
        this.size = size;
        this.totalElements = totalElements;
        this.totalPages = (int)Math.ceil(totalElements / (double)size);
        this.hasNext = page + 1 < this.totalPages;
    }
}
