package ai.youthmind.dto;

import io.swagger.v3.oas.annotations.media.Schema;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class CommunicationInsightsResponse {
    public UUID userId;
    @Schema(description = "Average sentence length in tokens")
    public double avgSentenceLength;
    @Schema(description = "Type-token ratio (vocabulary richness)")
    public double typeTokenRatio;
    @Schema(description = "Questions per token")
    public double questionRate;
    @Schema(description = "Exclamations per token")
    public double exclamationRate;
    @Schema(description = "Emojis per token")
    public double emojiRate;
    @Schema(description = "Average sentiment from AI analysis if available [0..1]")
    public Double avgSentiment;
    @Schema(description = "Top bigrams with counts")
    public Map<String, Long> topBigrams;
    @Schema(description = "Human-readable summary bullets")
    public List<String> summary;
    public Instant generatedAt;

    public CommunicationInsightsResponse(UUID userId, double avgSentenceLength, double typeTokenRatio, double questionRate,
                                         double exclamationRate, double emojiRate, Double avgSentiment,
                                         Map<String, Long> topBigrams, List<String> summary, Instant generatedAt) {
        this.userId = userId; this.avgSentenceLength = avgSentenceLength; this.typeTokenRatio = typeTokenRatio;
        this.questionRate = questionRate; this.exclamationRate = exclamationRate; this.emojiRate = emojiRate;
        this.avgSentiment = avgSentiment; this.topBigrams = topBigrams; this.summary = summary; this.generatedAt = generatedAt;
    }
}
