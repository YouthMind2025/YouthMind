package ai.youthmind.dto;

import io.swagger.v3.oas.annotations.media.Schema;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

public class WordCloudResponse {
    @Schema(description = "User ID")
    public UUID userId;
    @Schema(description = "Top word items with relative weight [0..1]")
    public List<WordCloudItem> items;
    @Schema(description = "Total tokens across user's content")
    public int totalTokens;
    @Schema(description = "Unique token count")
    public int uniqueTokens;
    @Schema(description = "Timestamp when generated (UTC)")
    public Instant generatedAt;

    public WordCloudResponse(UUID userId, List<WordCloudItem> items, int totalTokens, int uniqueTokens, Instant generatedAt) {
        this.userId = userId; this.items = items; this.totalTokens = totalTokens; this.uniqueTokens = uniqueTokens; this.generatedAt = generatedAt;
    }

    public static class WordCloudItem {
        public String word;
        public int count;
        public double weight; // normalized 0..1
        public WordCloudItem(String word, int count, double weight) { this.word = word; this.count = count; this.weight = weight; }
    }
}
