package ai.youthmind.dto;

import io.swagger.v3.oas.annotations.media.Schema;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

public class ActivityPatternsResponse {
    public UUID userId;
    @Schema(description = "Counts by hour of day [0..23]")
    public Map<Integer, Long> byHour;
    @Schema(description = "Counts by day of week (MON..SUN)")
    public Map<String, Long> byDayOfWeek;
    @Schema(description = "Average actions per day in the window")
    public double avgPerDay;
    @Schema(description = "Most active hour (0..23)")
    public Integer preferredHour;
    @Schema(description = "Most active day name")
    public String preferredDayOfWeek;
    @Schema(description = "Current daily streak length in days")
    public int currentStreakDays;
    @Schema(description = "Last activity timestamp (UTC)")
    public Instant lastActiveAt;

    public ActivityPatternsResponse(UUID userId, Map<Integer, Long> byHour, Map<String, Long> byDayOfWeek, double avgPerDay,
                                    Integer preferredHour, String preferredDayOfWeek, int currentStreakDays, Instant lastActiveAt) {
        this.userId = userId; this.byHour = byHour; this.byDayOfWeek = byDayOfWeek; this.avgPerDay = avgPerDay;
        this.preferredHour = preferredHour; this.preferredDayOfWeek = preferredDayOfWeek; this.currentStreakDays = currentStreakDays;
        this.lastActiveAt = lastActiveAt;
    }
}
