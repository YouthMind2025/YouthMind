package ai.youthmind.dto;

import lombok.Data;

/** Request body for setting resonance (like/unlike) */
@Data
public class ResonanceRequest {
    private boolean liked;
}
