package ai.youthmind.dto;

import lombok.Data;

/** Request body for setting collection (bookmark/unbookmark) */
@Data
public class CollectionRequest {
    private boolean collected;
}
