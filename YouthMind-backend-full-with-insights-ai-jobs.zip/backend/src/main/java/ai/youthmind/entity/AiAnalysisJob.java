package ai.youthmind.entity;

import jakarta.persistence.*;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "ai_analysis_jobs")
public class AiAnalysisJob {
    @Id
    @GeneratedValue
    private UUID id;

    @Column(name = "post_id", nullable = false)
    private UUID postId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status = Status.PENDING;

    @Column(name = "error", length = 2000)
    private String error;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt = Instant.now();

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt = Instant.now();

    public enum Status { PENDING, RUNNING, COMPLETED, FAILED }

    public UUID getId() { return id; }
    public UUID getPostId() { return postId; }
    public Status getStatus() { return status; }
    public String getError() { return error; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }

    public void setPostId(UUID postId) { this.postId = postId; }
    public void setStatus(Status status) { this.status = status; this.updatedAt = Instant.now(); }
    public void setError(String error) { this.error = error; this.updatedAt = Instant.now(); }
}
