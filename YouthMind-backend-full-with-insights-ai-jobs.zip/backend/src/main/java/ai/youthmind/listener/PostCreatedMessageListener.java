package ai.youthmind.listener;

import ai.youthmind.service.AIAnalysisService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

@Component
public class PostCreatedMessageListener implements MessageListener {

    private static final Logger log = LoggerFactory.getLogger(PostCreatedMessageListener.class);

    private final ObjectMapper mapper = new ObjectMapper();

    @Autowired(required = false)
    private AIAnalysisService aiAnalysisService;

    @Override
    public void onMessage(Message message, byte[] pattern) {
        try {
            if (aiAnalysisService == null) {
                log.debug("AIAnalysisService not available; skipping post_created handling");
                return;
            }
            String payload = new String(message.getBody(), StandardCharsets.UTF_8);
            JsonNode node = mapper.readTree(payload);
            String postIdStr = node.hasNonNull("postId") ? node.get("postId").asText() : null;
            if (postIdStr == null) {
                log.warn("post_created without postId: {}", payload);
                return;
            }
            UUID postId = UUID.fromString(postIdStr);
            aiAnalysisService.triggerAsyncAnalysis(postId);
            log.info("Triggered AI analysis for post {}", postId);
        } catch (Exception e) {
            log.error("Failed to process post_created message: {}", e.getMessage());
        }
    }
}
