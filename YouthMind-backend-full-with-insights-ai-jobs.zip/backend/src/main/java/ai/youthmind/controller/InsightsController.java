package ai.youthmind.controller;

import ai.youthmind.dto.ActivityPatternsResponse;
import ai.youthmind.dto.CommunicationInsightsResponse;
import ai.youthmind.dto.WordCloudResponse;
import ai.youthmind.service.InsightsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/insights")
@Tag(name = "Insights", description = "User behavioral insights & analytics")
public class InsightsController {

    private final InsightsService insightsService;

    public InsightsController(InsightsService insightsService) {
        this.insightsService = insightsService;
    }

    @GetMapping("/wordcloud/{userId}")
    @Operation(summary = "Generate word cloud for a user's content")
    public ResponseEntity<WordCloudResponse> wordCloud(@PathVariable UUID userId,
                                                       @RequestParam(name = "top", defaultValue = "50") int topN) {
        return ResponseEntity.ok(insightsService.buildWordCloud(userId, Math.max(5, Math.min(topN, 200))));
    }

    @GetMapping("/communication/{userId}")
    @Operation(summary = "Analyze user's communication style")
    public ResponseEntity<CommunicationInsightsResponse> communication(@PathVariable UUID userId,
                                                                       @RequestParam(name = "bigrams", defaultValue = "10") int topBigrams) {
        return ResponseEntity.ok(insightsService.analyzeCommunicationStyle(userId, Math.max(5, Math.min(topBigrams, 50))));
    }

    @GetMapping("/activity/{userId}")
    @Operation(summary = "Analyze user's activity patterns")
    public ResponseEntity<ActivityPatternsResponse> activity(@PathVariable UUID userId,
                                                             @RequestParam(name = "days", defaultValue = "180") int windowDays) {
        return ResponseEntity.ok(insightsService.activityPatterns(userId, Math.max(7, Math.min(windowDays, 365))));
    }
}
