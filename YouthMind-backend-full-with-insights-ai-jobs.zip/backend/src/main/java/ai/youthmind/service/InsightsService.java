package ai.youthmind.service;

import ai.youthmind.dto.ActivityPatternsResponse;
import ai.youthmind.dto.CommunicationInsightsResponse;
import ai.youthmind.dto.WordCloudResponse;
import ai.youthmind.dto.WordCloudResponse.WordCloudItem;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
public class InsightsService {

    @PersistenceContext
    private EntityManager em;

    private static final Pattern WORD_PATTERN = Pattern.compile("[\\p{L}']{2,}");

    private static final Set<String> STOPWORDS = buildStopwords();

    @Cacheable(cacheNames = "insights:wordcloud", key = "#userId")
    public WordCloudResponse buildWordCloud(UUID userId, int topN) {
        List<String> texts = fetchUserTexts(userId);
        Map<String, Integer> freq = new HashMap<>();
        for (String t : texts) tokenize(t).forEach(w -> freq.merge(w, 1, Integer::sum));
        List<Map.Entry<String, Integer>> sorted = freq.entrySet().stream()
                .sorted((a,b) -> Integer.compare(b.getValue(), a.getValue()))
                .limit(topN)
                .toList();
        int max = sorted.isEmpty()? 1 : sorted.get(0).getValue();
        List<WordCloudItem> items = sorted.stream()
                .map(e -> new WordCloudItem(e.getKey(), e.getValue(), (double)e.getValue() / max))
                .toList();
        int totalTokens = freq.values().stream().mapToInt(Integer::intValue).sum();
        return new WordCloudResponse(userId, items, totalTokens, freq.size(), Instant.now());
    }

    @Cacheable(cacheNames = "insights:communication", key = "#userId")
    public CommunicationInsightsResponse analyzeCommunicationStyle(UUID userId, int topBigrams) {
        List<String> texts = fetchUserTexts(userId);
        String all = String.join("\n", texts);
        int tokens = tokenize(all).size();
        int types = new HashSet<>(tokenize(all)).size();
        double ttr = tokens == 0 ? 0.0 : (double) types / tokens;

        List<String> sentences = splitSentences(all);
        double avgSentenceLen = sentences.isEmpty()? 0.0 : sentences.stream().mapToInt(s -> tokenize(s).size()).average().orElse(0.0);

        long q = countChar(all, '?');
        long ex = countChar(all, '!');
        long emojis = countEmojis(all);
        double base = Math.max(1, tokens);
        double questionRate = q / base;
        double exclamationRate = ex / base;
        double emojiRate = emojis / base;

        Map<String, Long> bigrams = topBigrams(all, topBigrams);

        Double avgSentiment = avgSentimentFromAi(userId);

        List<String> summary = new ArrayList<>();
        if (avgSentenceLen > 20) summary.add("Long-form writing style");
        if (ttr > 0.5) summary.add("High vocabulary richness");
        if (questionRate > 0.02) summary.add("Inquisitive tone");
        if (exclamationRate > 0.02) summary.add("Expressive tone");
        if (emojiRate > 0.01) summary.add("Frequent emoji usage");

        return new CommunicationInsightsResponse(userId, avgSentenceLen, ttr, questionRate, exclamationRate,
                emojiRate, avgSentiment, bigrams, summary, Instant.now());
    }

    @Cacheable(cacheNames = "insights:activity", key = "#userId")
    public ActivityPatternsResponse activityPatterns(UUID userId, int windowDays) {
        LocalDateTime since = LocalDateTime.now(ZoneOffset.UTC).minusDays(windowDays);
        Query postQ = em.createNativeQuery("SELECT created_at FROM posts WHERE user_id = :uid AND created_at >= :since");
        postQ.setParameter("uid", userId);
        postQ.setParameter("since", since);
        @SuppressWarnings("unchecked")
        List<java.sql.Timestamp> postTs = postQ.getResultList();

        Query comQ = em.createNativeQuery("SELECT created_at FROM comments WHERE author_id = :uid AND created_at >= :since");
        comQ.setParameter("uid", userId);
        comQ.setParameter("since", since);
        @SuppressWarnings("unchecked")
        List<java.sql.Timestamp> comTs = comQ.getResultList();

        List<LocalDateTime> all = new ArrayList<>();
        postTs.forEach(t -> all.add(t.toLocalDateTime()));
        comTs.forEach(t -> all.add(t.toLocalDateTime()));
        all.sort(Comparator.naturalOrder());

        Map<Integer, Long> byHour = all.stream()
                .collect(Collectors.groupingBy(dt -> dt.getHour(), TreeMap::new, Collectors.counting()));
        Map<DayOfWeek, Long> byDow = all.stream()
                .collect(Collectors.groupingBy(dt -> dt.getDayOfWeek(), () -> new EnumMap<>(DayOfWeek.class), Collectors.counting()));

        for (int h=0; h<24; h++) byHour.putIfAbsent(h, 0L);
        for (DayOfWeek d : DayOfWeek.values()) byDow.putIfAbsent(d, 0L);

        double days = Math.max(1, ChronoUnit.DAYS.between(since, LocalDateTime.now(ZoneOffset.UTC)));
        double avgPerDay = all.size()/days;

        Integer preferredHour = byHour.entrySet().stream().max(Map.Entry.comparingByValue()).map(Map.Entry::getKey).orElse(null);
        DayOfWeek preferredDow = byDow.entrySet().stream().max(Map.Entry.comparingByValue()).map(Map.Entry::getKey).orElse(null);

        int streak = computeCurrentStreak(all.stream().map(LocalDateTime::toLocalDate).collect(Collectors.toCollection(LinkedHashSet::new)));
        Instant lastActive = all.isEmpty()? null : all.get(all.size()-1).toInstant(ZoneOffset.UTC);

        Map<String, Long> byDowStr = new LinkedHashMap<>();
        Arrays.stream(DayOfWeek.values()).forEach(d -> byDowStr.put(d.name(), byDow.getOrDefault(d, 0L)));

        return new ActivityPatternsResponse(userId, byHour, byDowStr, avgPerDay, preferredHour,
                preferredDow == null? null : preferredDow.name(), streak, lastActive);
    }

    private static int computeCurrentStreak(Set<LocalDate> activeDaysOrdered) {
        if (activeDaysOrdered.isEmpty()) return 0;
        List<LocalDate> days = new ArrayList<>(activeDaysOrdered);
        Collections.sort(days);
        int streak = 0;
        LocalDate cursor = LocalDate.now();
        for (int i = days.size()-1; i >= 0; i--) {
            LocalDate d = days.get(i);
            if (d.equals(cursor)) { streak++; cursor = cursor.minusDays(1); }
            else if (d.equals(cursor.minusDays(1))) { streak++; cursor = cursor.minusDays(1); }
            else break;
        }
        return streak;
    }

    private Double avgSentimentFromAi(UUID userId) {
        Query q = em.createNativeQuery("SELECT AVG(a.sentiment_score) FROM ai_analysis a JOIN posts p ON a.post_id = p.id WHERE p.user_id = :uid");
        q.setParameter("uid", userId);
        Object r = q.getSingleResult();
        if (r == null) return null;
        if (r instanceof BigDecimal bd) return bd.doubleValue();
        if (r instanceof Number n) return n.doubleValue();
        return null;
    }

    private static long countChar(String s, char c) { return s.chars().filter(ch -> ch == c).count(); }

    private static long countEmojis(String s) {
        return s.codePoints().filter(cp -> Character.getType(cp) == Character.OTHER_SYMBOL).count();
    }

    private static Map<String, Long> topBigrams(String text, int top) {
        List<String> toks = tokenize(text);
        Map<String, Long> big = new HashMap<>();
        for (int i=0; i+1<toks.size(); i++) {
            String b = toks.get(i) + " " + toks.get(i+1);
            big.merge(b, 1L, Long::sum);
        }
        return big.entrySet().stream()
                .sorted((a,b) -> Long.compare(b.getValue(), a.getValue()))
                .limit(top)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (x,y)->x, LinkedHashMap::new));
    }

    private static List<String> tokenize(String text) {
        List<String> out = new ArrayList<>();
        if (text == null) return out;
        Matcher m = WORD_PATTERN.matcher(text.toLowerCase(Locale.ROOT));
        while (m.find()) {
            String w = m.group();
            if (!STOPWORDS.contains(w)) out.add(w);
        }
        return out;
    }

    private static Set<String> buildStopwords() {
        String[] en = ("a,an,the,and,or,of,to,in,is,are,was,were,be,been,being,for,on,with,as,by,at,from,that,this,it,its,\n" +
                "i,you,he,she,we,they,them,his,her,our,your,my,me,him,who,whom,which,what,when,where,why,how,not,no,yes,do,does,did\n").split(",|\n");
        String[] ar = "و,في,على,من,إلى,عن,أن,إن,كان,كانت,لقد,قد,ما,لا,لم,لن,هذا,هذه,ذلك,تلك".split(",");
        Set<String> s = new HashSet<>();
        for (String w : en) { String t = w.trim(); if (!t.isEmpty()) s.add(t); }
        for (String w : ar) { String t = w.trim(); if (!t.isEmpty()) s.add(t); }
        return s;
    }

    private List<String> fetchUserTexts(UUID userId) {
        List<String> texts = new ArrayList<>();
        Query p = em.createNativeQuery("SELECT content FROM posts WHERE user_id = :uid");
        p.setParameter("uid", userId);
        @SuppressWarnings("unchecked") List<String> postTexts = p.getResultList();
        texts.addAll(postTexts);
        Query c = em.createNativeQuery("SELECT content FROM comments WHERE author_id = :uid");
        c.setParameter("uid", userId);
        @SuppressWarnings("unchecked") List<String> commentTexts = c.getResultList();
        texts.addAll(commentTexts);
        return texts;
    }

    private static List<String> splitSentences(String text) {
        if (text == null || text.isBlank()) return List.of();
        return Arrays.stream(text.split("(?<=[.!?])\s+")).toList();
    }
}
