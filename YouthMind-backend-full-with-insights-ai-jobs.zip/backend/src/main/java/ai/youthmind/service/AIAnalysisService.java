package ai.youthmind.service;

import ai.youthmind.entity.AiAnalysisJob;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.*;

import ai.youthmind.ai.AiAnalysisJobRepository;

@Service
public class AIAnalysisService {

    private final AiAnalysisJobRepository jobRepository;

    @PersistenceContext
    private EntityManager em;

    public AIAnalysisService(AiAnalysisJobRepository jobRepository) {
        this.jobRepository = jobRepository;
    }

    @Transactional
    public AiAnalysisJob triggerAsyncAnalysis(UUID postId) {
        AiAnalysisJob job = new AiAnalysisJob();
        job.setPostId(postId);
        job = jobRepository.save(job);
        processAsync(postId, job.getId());
        return job;
    }

    @Async("aiExecutor")
    @Transactional
    public void processAsync(UUID postId, UUID jobId) {
        AiAnalysisJob job = jobRepository.findById(jobId).orElseThrow();
        try {
            job.setStatus(AiAnalysisJob.Status.RUNNING);
            jobRepository.save(job);

            long start = System.currentTimeMillis();
            String content = fetchPostContent(postId);
            Map<String, Integer> counts = countTokens(content);
            double sentiment = heuristicSentiment(counts);
            double empathy = heuristicEmpathy(counts);
            List<String> questions = generateQuestions(content);
            int ms = (int)(System.currentTimeMillis() - start);

            // Store into ai_analysis table using native SQL to avoid entity mapping assumptions
            em.createNativeQuery("""

                INSERT INTO ai_analysis (post_id, sentiment_score, empathy_score, generated_questions, processing_time_ms)

                VALUES (:p, :s, :e, CAST(:g AS json), :ms)

                ON CONFLICT (post_id) DO UPDATE

                SET sentiment_score = EXCLUDED.sentiment_score,

                    empathy_score = EXCLUDED.empathy_score,

                    generated_questions = EXCLUDED.generated_questions,

                    processing_time_ms = EXCLUDED.processing_time_ms

            """)

                    .setParameter("p", postId)

                    .setParameter("s", BigDecimal.valueOf(round(sentiment)))

                    .setParameter("e", BigDecimal.valueOf(round(empathy)))

                    .setParameter("g", toJsonArray(questions))

                    .setParameter("ms", ms)

                    .executeUpdate();

            job.setStatus(AiAnalysisJob.Status.COMPLETED);
            jobRepository.save(job);
        } catch (Exception ex) {
            job.setStatus(AiAnalysisJob.Status.FAILED);
            job.setError(ex.getMessage());
            jobRepository.save(job);
        }
    }

    private static double round(double v) { return Math.max(0.0, Math.min(1.0, Math.round(v * 100.0) / 100.0)); }

    private String fetchPostContent(UUID postId) {
        Query q = em.createNativeQuery("SELECT content FROM posts WHERE id = :id");
        q.setParameter("id", postId);
        Object r = q.getSingleResult();
        return r == null ? "" : r.toString();
    }

    private static Map<String,Integer> countTokens(String text) {
        Map<String,Integer> m = new HashMap<>();
        if (text == null) return m;
        String[] toks = text.toLowerCase(Locale.ROOT).split("[^\\p{L}']+");
        for (String t : toks) if (!t.isBlank()) m.merge(t, 1, Integer::sum);
        return m;
    }

    private static double heuristicSentiment(Map<String,Integer> counts) {
        String[] pos = {"good","great","love","happy","excellent","amazing","wonderful","cool","nice","grateful"};
        String[] neg = {"bad","sad","hate","angry","terrible","awful","worried","anxious","depressed","upset"};
        int p = 0, n = 0;
        for (String w : pos) p += counts.getOrDefault(w,0);
        for (String w : neg) n += counts.getOrDefault(w,0);
        int total = p + n;
        if (total == 0) return 0.5;
        return (double)p / total;
    }

    private static double heuristicEmpathy(Map<String,Integer> counts) {
        String[] emp = {"feel","understand","sorry","hear","there","support","with you","together","listen"};
        int e = 0; for (String w : emp) e += counts.getOrDefault(w,0);
        int total = counts.values().stream().mapToInt(Integer::intValue).sum();
        if (total == 0) return 0.5;
        return Math.min(1.0, e / Math.max(10.0, total/20.0));
    }

    private static List<String> generateQuestions(String content) {
        List<String> qs = new ArrayList<>();
        qs.add("What made you feel this way?");
        qs.add("What would help you most right now?");
        qs.add("Is there someone you can talk to about this?");
        if (content != null && content.length() > 120) qs.add("Can you share more details about the situation?");
        return qs.size() > 3 ? qs.subList(0,3) : qs;
    }

    private static String toJsonArray(List<String> items) {
        StringBuilder sb = new StringBuilder("[");
        for (int i=0;i<items.size();i++) {
            if (i>0) sb.append(',');
            sb.append('"').append(items.get(i).replace("\"","\\\"")).append('"');
        }
        sb.append(']');
        return sb.toString();
    }
}
